# Spam Email Classification (Baseline)

This module provides a baseline machine learning pipeline for spam detection using scikit-learn.

## 📦 Environment Setup

```bash
pip install -r requirements.txt
```

## 🧠 Training

```bash
python scripts/train_baseline.py
```

The model and vectorizer will be saved to the `artifacts/` directory.

## 🔍 Prediction

### Predict a single email

```bash
python scripts/predict_baseline.py --model artifacts/model_svm.joblib --vectorizer artifacts/vectorizer.joblib --text "You won a free prize!"
```

### Predict from CSV

```bash
python scripts/predict_baseline.py --model artifacts/model_svm.joblib --vectorizer artifacts/vectorizer.joblib --csv data/test_samples.csv
```

Predictions will be saved to `data/test_samples_predicted.csv`.
