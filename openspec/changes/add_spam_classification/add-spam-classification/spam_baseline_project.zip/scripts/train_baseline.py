import os
import argparse
import json
import re
import sys
from pprint import pprint

import joblib
import numpy as np
import pandas as pd

DEFAULT_URL = "https://raw.github.com/PacktPublishing/Hands-On-Artificial-Intelligence-for-Cybersecurity/refs/heads/master/Chapter03/datasets/sms_spam_no_header.csv"
RANDOM_STATE = 42

def clean_text(s: str) -> str:
    if not isinstance(s, str):
        return ""
    s = s.lower()
    s = re.sub(r"[^a-z0-9\s]", "", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s

def load_data(path_or_url: str):
    try:
        df = pd.read_csv(path_or_url, header=None, names=["label", "message"], encoding="utf-8", engine="python")
    except Exception:
        df = pd.read_csv(path_or_url, header=None, names=["label", "message"], encoding="latin-1", engine="python")
    df = df.dropna().reset_index(drop=True)
    df["message_clean"] = df["message"].apply(clean_text)
    df["label_bin"] = df["label"].apply(lambda x: 1 if str(x).strip().lower() in ("spam", "1", "true") else 0)
    return df

def train(df: pd.DataFrame, model_type: str = "svm", out_dir: str = "artifacts"):
    os.makedirs(out_dir, exist_ok=True)
    X = df["message_clean"].values
    y = df["label_bin"].values

    try:
        from sklearn.feature_extraction.text import TfidfVectorizer
        from sklearn.model_selection import train_test_split
        from sklearn.metrics import classification_report, confusion_matrix
        from sklearn.svm import LinearSVC
        from sklearn.linear_model import LogisticRegression
    except Exception as e:
        print("Failed to import scikit-learn or its dependencies:", repr(e))
        sys.exit(1)

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=RANDOM_STATE)
    vectorizer = TfidfVectorizer(min_df=2, ngram_range=(1, 2))
    X_train_tfidf = vectorizer.fit_transform(X_train)
    X_test_tfidf = vectorizer.transform(X_test)

    if model_type == "svm":
        model = LinearSVC(random_state=RANDOM_STATE)
    elif model_type == "logreg":
        model = LogisticRegression(max_iter=1000, random_state=RANDOM_STATE)
    else:
        raise ValueError("Unknown model type: choose 'svm' or 'logreg'")

    model.fit(X_train_tfidf, y_train)
    preds = model.predict(X_test_tfidf)

    from sklearn.metrics import classification_report, confusion_matrix
    report = classification_report(y_test, preds, output_dict=True)
    cm = confusion_matrix(y_test, preds).tolist()

    metrics = {"classification_report": report, "confusion_matrix": cm, "model_type": model_type}
    model_path = os.path.join(out_dir, f"model_{model_type}.joblib")
    vec_path = os.path.join(out_dir, "vectorizer.joblib")
    metrics_path = os.path.join(out_dir, "metrics.json")

    joblib.dump(model, model_path)
    joblib.dump(vectorizer, vec_path)
    with open(metrics_path, "w", encoding="utf-8") as fh:
        json.dump(metrics, fh, indent=2)

    print("Training complete. Artifacts written to:")
    print(f"  model: {model_path}")
    print(f"  vectorizer: {vec_path}")
    print(f"  metrics: {metrics_path}")
    pprint(metrics)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", default=DEFAULT_URL, help="Path or URL to dataset CSV")
    parser.add_argument("--model", choices=("svm", "logreg"), default="svm")
    parser.add_argument("--out", default="artifacts")
    args = parser.parse_args()
    df = load_data(args.data)
    train(df, model_type=args.model, out_dir=args.out)
